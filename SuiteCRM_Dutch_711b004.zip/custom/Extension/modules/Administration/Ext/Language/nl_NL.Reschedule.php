<?php
    
$mod_strings['LBL_RESCHEDULE_REBUILD'] = 'Repair Reschedule';
$mod_strings['LBL_RESCHEDULE_REBUILD_DESC'] = 'Repairs the Reschedule Module';
$mod_strings['LBL_RESCHEDULE_ADMIN'] = 'Reschedule Settings';
$mod_strings['LBL_RESCHEDULE_ADMIN_DESC'] = 'Configure and Manage Reschedule';
$mod_strings['LBL_REPAIR_RESCHEDULE_DONE'] = 'Reschedule Successfully Repaired';
$mod_strings['LBL_SALESAGILITY_ADMIN'] = 'Advanced OpenAdmin';

