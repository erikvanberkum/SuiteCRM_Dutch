<?php
/**
 * en_us.lang.php
 * @author SalesAgility <support@salesagility.com>
 * Date: 11/07/13
 */

$mod_strings['fieldTypes']['dynamicenum'] = 'Dynamisch Drop-Down';