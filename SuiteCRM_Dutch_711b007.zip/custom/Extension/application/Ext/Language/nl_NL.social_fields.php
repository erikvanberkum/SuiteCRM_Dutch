<?php
/**
 * Dutch Language file SuiteCRM version 7 
 * Copyright (c) 2014 Acniti (http:/www.acniti.com)
 * All rights reserved.
 * 
 * Permission is granted for use, copying, modification, distribution,
 * and distribution of modified versions of this work as long as the
 * above copyright notice is included.  
 *  
 * Social Feed Language Strings.
 */

$app_strings['FACEBOOK_USER_C'] = 'Facebook';
$app_strings['TWITTER_USER_C'] = 'Twitter';
$app_strings['LBL_FACEBOOK_USER_C'] = 'Facebook Gebruiker';
$app_strings['LBL_TWITTER_USER_C'] = 'Twitter Gebruiker';
$app_strings['LBL_PANEL_SOCIAL_FEED'] = 'Social Feed details';