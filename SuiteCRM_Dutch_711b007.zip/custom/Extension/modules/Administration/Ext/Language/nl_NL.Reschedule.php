<?php
/**
 * Dutch Language file SuiteCRM version 7 
 * Copyright (c) 2014 Acniti (http:/www.acniti.com)
 * All rights reserved.
 *
 * Permission is granted for use, copying, modification, distribution,
 * and distribution of modified versions of this work as long as the
 * above copyright notice is included.
 */    
$mod_strings['LBL_RESCHEDULE_REBUILD'] = 'Repareer Reschedule';
$mod_strings['LBL_RESCHEDULE_REBUILD_DESC'] = 'Repareer de Reschedule Module';
$mod_strings['LBL_RESCHEDULE_ADMIN'] = 'Reschedule instellingen';
$mod_strings['LBL_RESCHEDULE_ADMIN_DESC'] = 'Instellingen voor Reschedule';
$mod_strings['LBL_REPAIR_RESCHEDULE_DONE'] = 'Reschedule succesvol gerepareerd';
$mod_strings['LBL_SALESAGILITY_ADMIN'] = 'Advanced OpenAdmin';

