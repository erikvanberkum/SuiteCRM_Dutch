<?php
 /**
 * Dutch Language file SuiteCRM version 7 
 * Copyright (c) 2014 Acniti (http:/www.acniti.com)
 * All rights reserved.
 *
 * Permission is granted for use, copying, modification, distribution,
 * and distribution of modified versions of this work as long as the
 * above copyright notice is included.
 */
$mod_strings['LBL_UPDATE_QUICKCRM_TITLE'] = "QuickCRM Update";
$mod_strings['LBL_UPDATE_QUICKCRM'] = "Definitie velden opnieuw opbouwen";
$mod_strings['LBL_QUICKCRM'] = 'QuickCRM Mobile';
$mod_strings['LBL_CONFIG_QUICKCRM_TITLE'] = "Instellingen van QuickCRM Mobile";
$mod_strings['LBL_CONFIG_QUICKCRM'] = "Definitie van zichtbare modulen en velden";
$mod_strings['LBL_UPDATE_MSG'] = '<strong>Applicatie updated voor QuickCRM on mobile</strong><br/>U kunt de mobile versie benaderen op:';
$mod_strings['LBL_ERR_DIR_MSG'] = 'Sommige bestanden konden niet worden gecreerd. Controleer de schrijf rechten voor: ';


