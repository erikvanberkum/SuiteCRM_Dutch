<?php

$mod_strings = array_merge($mod_strings,
    array(
        'LBL_SUITE_SUPERCHARGED' => "Supercharged door SuiteCRM",
        'LBL_SUITE_POWERED_BY' => "Powered door SugarCRM",
        'LBL_SUITE_TOP' => "Terug naar boven",
        'LBL_SUITE_PRINT' => "Deze pagina afdruken",
        'LBL_SUITE_DESC1' => 'SuiteCRM is geschreven en samengesteld door SalesAgility, werelds meest deskundige SugarCRM adviesbureaus.',
        'LBL_SUITE_DESC2' => 'SuiteCRM  is bedoelt om de belofte van SugarCRM te leveren - een vrij beschikbaar open source CRM project dat grote functionaliteit, met een toegewijde gemeenschap combineert.',
        'LBL_SUITE_DESC3' => 'Er zal geen software licentie zijn voor het gedeelte beheert door SalesAgility. Alle code is gratis. Alle code is gratis beschikbaar voor download. Er is geen dubbele agenda om de code in rekening te brengen. Het is en het zal altijd gratis en open source blijven. Er zullen geen betaalde versies komen.',
        'LBL_QUICK_ACCOUNT' => 'Bedrijf aanmaken',
        'LBL_QUICK_CONTACT' => 'Contactpersoon aanmaken',
        'LBL_QUICK_OPPORTUNITY' => 'Kans aanmaken',
        'LBL_QUICK_LEAD' => 'Lead aanmaken',
        'LBL_QUICK_DOCUMENT' => 'Document aanmaken',
        'LBL_QUICK_CALL' => 'Telefoongesprek aanmaken',
        'LBL_QUICK_TASK' => 'Taak aanmaken',
    )
);
?>