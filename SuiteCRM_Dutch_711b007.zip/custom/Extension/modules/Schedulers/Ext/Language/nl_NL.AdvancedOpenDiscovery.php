<?php
$mod_strings['LBL_AODOPTIMISEINDEX'] = 'Optimaliseer Advanced OpenDiscovery index';
$mod_strings['LBL_AODINDEXUNINDEXED'] = 'Indexeer niet geindexeerde documenten';
